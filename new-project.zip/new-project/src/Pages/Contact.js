import React from 'react'
import Topber from '../Component/Topber'
import Navber from '../Component/Navber'


export function Contact() {
  return (
    <>
      <Topber />
      <Navber />
    </>
  )
}

export default Contact
