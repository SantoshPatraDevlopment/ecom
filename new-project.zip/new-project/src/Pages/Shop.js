import React from 'react'
import Topber from '../Component/Topber'
import Navber from '../Component/Navber'

export function Shop() {
  return (
    <>
      <Topber />
      <Navber />
    </>
  )
}

export default Shop
