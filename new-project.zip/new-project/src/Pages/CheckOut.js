import React from 'react'
import Topber from '../Component/Topber'
import Navber from '../Component/Navber'

export function CheckOut() {
    return (
        <>
            <Topber />
            <Navber />
        </>
    )
}

export default CheckOut
