import React from 'react'
import Topber from '../Component/Topber'
import Navber from '../Component/Navber'

export function Cart() {
    return (
        <>
            <Topber />
            <Navber />
        </>
    )
}

export default Cart
