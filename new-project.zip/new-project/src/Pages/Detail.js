import React from 'react'
import Topber from '../Component/Topber'
import Navber from '../Component/Navber'

export function Detail() {
    return (
        <>
            <Topber />
            <Navber />
        </>
    )
}

export default Detail
